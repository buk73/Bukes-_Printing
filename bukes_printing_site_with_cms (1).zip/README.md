# Bukes Printing Website with CMS

A dynamic portfolio website with category filters, lightbox previews, and Netlify CMS integration for easy content management.

---

## Deployment Instructions

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit with CMS"
git remote add origin https://github.com/YOUR_USERNAME/bukes-printing-site.git
git push -u origin main
```

---

### 2. Deploy on Netlify

- Go to [Netlify](https://www.netlify.com/)
- Click **Add new site > Import from Git**
- Choose GitHub and select your repository
- Leave default settings and deploy

---

### 3. Enable Identity and Git Gateway

1. Go to your Netlify site dashboard
2. **Site settings > Identity > Enable Identity**
3. In Identity settings:
   - Enable **Git Gateway**
   - Set **Registration preferences** to **Invite only**
   - Invite yourself via your GitHub-linked email

4. Access the CMS at: `https://your-site-name.netlify.app/admin`

---

## Editing Content

- Go to `/admin` and log in
- Add/edit portfolio items (image, caption, category)
- Changes are committed to GitHub and auto-published by Netlify

---

## Files

- `index.html` – Static homepage with Netlify Identity integration
- `admin/config.yml` – Netlify CMS configuration
- `portfolio.json` – Fallback/static data
- `uploads/` – Media folder (created automatically when uploading)

---
